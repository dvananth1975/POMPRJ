import allure
import openpyxl
import pytest
import self
from allure_commons.types import AttachmentType
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver import ChromeOptions, chrome
from Pages.LoginPage import LoginPage


def get_data(sheetName):
    workbook = openpyxl.load_workbook("..//excel//testdata.xlsx")
    sheet = workbook[sheetName]
    totalrows = sheet.max_row
    totalcols = sheet.max_column
    mainlist = []
    for i in range(2, totalrows + 1):
        dataList = []
        print("The datalist is", dataList)
        for j in range(1, totalcols + 1):
            data = sheet.cell(row=i, column=j).value
            dataList.insert(j, data)
            print("The datalist is", dataList)
        mainlist.insert(i, dataList)
    print("The mainlist is ", mainlist)
    return mainlist


xl = get_data("LoginTest")
