import allure
import pytest
from allure_commons.types import AttachmentType
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver import ChromeOptions, chrome

from selenium.webdriver import  ChromeOptions, chrome

# from selenium.webdriver import ChromeOptions, Chrome
# opts = ChromeOptions()
# opts.add_experimental_option("detach", True)
# driver = Chrome(opts)

@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    setattr(item, "rep_" + rep.when, rep)
    return rep
@pytest.fixture()
def log_on_failure(request,get_browser):
     yield
     item = request.node
     driver=get_browser
     if item.rep_call.failed:
        allure.attach(driver.get_screenshot_as_png(), name="dologin", attachment_type=AttachmentType.PNG)
@pytest.fixture(params=["edge","firefox"],scope="class")
def get_browser(request):
    if request.param == "edge":
     driver = webdriver.Edge()
    if request.param == "firefox":
       driver= webdriver.Firefox()
    request.cls.driver = driver
    driver.get("https://mytripspreprod.travelsecurity.com/")
    driver.maximize_window()
    yield driver
   # driver.quit