import allure
import openpyxl
import pytest
import self
from allure_commons.types import AttachmentType
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver import ChromeOptions, chrome

from Pages.LoginPage import LoginPage
from Testcases.BaseTest import BaseTest
from Utilities import dataprovider
from Utilities import LogUtil
import logging
from Utilities.LogUtil import Logger

log = Logger(__name__, logging.INFO)


class Test_LoginTest(BaseTest):

    @pytest.mark.parametrize("username,password", dataprovider.get_data("LoginTest"))
    def test_dologin(self, username, password):
        log.logger.info("Logon to Mytrips started")
        loginpg = LoginPage(self.driver)
        loginpg.fillForm(username, password)
        log.logger.info("Logon to Mytrips completed")
# driver.find_element(By.XPATH ,"//*[@id=\"MainContent_LoginUser_txtUserName\"] ").send_keys(username)
# driver.find_element(By.XPATH,"//*[@id=\"MainContent_LoginUser_txtPassword\"]").send_keys(password)
# driver.find_element(By.XPATH,"//*[@id=\"onetrust-accept-btn-handler\"]").click()
